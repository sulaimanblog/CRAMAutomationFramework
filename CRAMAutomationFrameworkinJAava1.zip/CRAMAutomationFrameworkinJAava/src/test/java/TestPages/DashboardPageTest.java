package TestPages;

import Base.Baseclass;
import ConfigReader.ConfigReader;
import Pages.DashboardPage;
import Pages.Login;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.By;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.Assert;
import org.testng.annotations.Test;

import java.time.Duration;


public class DashboardPageTest  extends Baseclass
{
    public static final Logger logger = LoggerFactory.getLogger(DashboardPageTest.class);
    DashboardPage dashboard;
    Login login;
    WebDriverWait wait;

    @Test
    public void logoutdashboardscreen() {
        try {
            logger.info("Starting logoutdashboardscreen test");
            extentTest.get().log(Status.INFO, "Starting logout test");
            login = new Login(driver);
            String username = ConfigReader.getProperty("username");
            String password = ConfigReader.getProperty("password");
            extentTest.get().log(Status.INFO, "Logging in first");
            login.login(username, password);
            dashboard = new DashboardPage(driver);

            String actual="Risk Dashboardd";
            String exp=driver.findElement(By.xpath("//p[text()='Risk Dashboard']")).getText();
            Assert.assertEquals(actual,exp,"Failed assertion");

            dashboard.risk_Compliance_Register();

            String actuall="Risk Compliance Register";
            String expp=driver.findElement(By.xpath("//p[text()='Risk Compliance Register']")).getText();
            Assert.assertEquals(actuall,expp,"Failed assertion");

            dashboard.logout();
            System.out.println("logout page");
            extentTest.get().log(Status.PASS, "Logout test completed successfully");
            logger.info("logoutdashboardscreen test completed successfully");

        } catch (Exception e) {
            logger.error("Logout test failed: {}", e.getMessage());
            extentTest.get().log(Status.FAIL, "Logout test failed: " + e.getMessage());
            throw new AssertionError("Logout test failed", e);
        }
    }


}
