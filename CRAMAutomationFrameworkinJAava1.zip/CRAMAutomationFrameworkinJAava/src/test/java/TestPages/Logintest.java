package TestPages;

import Base.Baseclass;
import ConfigReader.ConfigReader;
import Pages.DashboardPage;
import Pages.Login;
import com.aventstack.extentreports.Status;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeClass;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.Test;


public class Logintest extends Baseclass
{
    public static final Logger logger = LoggerFactory.getLogger(Logintest.class);
    DashboardPage dashboard;
    Login login;

    @Test
    public void verifyLoginWithValidCredentials() {
        try {
            logger.info("Starting verifyLoginWithValidCredentials test");
            extentTest.get().log(Status.INFO, "Starting login test with valid credentials");

            login = new Login(driver);
            String username = ConfigReader.getProperty("username");
            String password = ConfigReader.getProperty("password");

            extentTest.get().log(Status.INFO, "Using username from config: " + username);
            login.login(username, password);

            extentTest.get().log(Status.PASS, "Login test completed successfully");
            logger.info("verifyLoginWithValidCredentials test completed successfully");

        } catch (Exception e) {
            logger.error("Login test failed: {}", e.getMessage());
            extentTest.get().log(Status.FAIL, "Login test failed: " + e.getMessage());
            throw new AssertionError("Login test failed", e);
        }
    }





}
