package Pages;

import Base.Baseclass;
import com.aventstack.extentreports.Status;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.time.Duration;

public class Login
{

    WebDriver driver;
    WebDriverWait wait;
    public static final Logger logger = LoggerFactory.getLogger(Login.class);

    @FindBy(xpath = "//input[@placeholder='Username']")
    WebElement usernameField;

    @FindBy(xpath = "//input[@placeholder='Password']")
    WebElement passwordField;

    @FindBy(xpath = "//div[@class='catcha-container captcha-no-select']/child::span")
    WebElement captchaElement;

    @FindBy(xpath = "//input[@placeholder='Enter Captcha']")
    WebElement captchaInputField;

    @FindBy(xpath = "//button[@type='submit']")
    WebElement loginButton;

    public Login(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        PageFactory.initElements(driver, this);
    }

    public void login(String username, String password) {
        try {
            logger.info("Attempting to login with username: {}", username);
            Baseclass.extentTest.get().log(Status.INFO, "Entering username: " + username);

            wait.until(ExpectedConditions.elementToBeClickable(usernameField)).sendKeys(username);
            passwordField.sendKeys(password);
            Baseclass.extentTest.get().log(Status.INFO, "Entered password");

            wait.until(ExpectedConditions.visibilityOf(captchaElement));
            String captchaText = captchaElement.getText().trim();
            if (captchaText.isEmpty()) {
                String errorMsg = "CAPTCHA text is empty";
                logger.error(errorMsg);
                Baseclass.extentTest.get().log(Status.FAIL, errorMsg);
                throw new RuntimeException(errorMsg);
            }

            captchaInputField.sendKeys(captchaText);
            Baseclass.extentTest.get().log(Status.INFO, "Entered CAPTCHA: " + captchaText);

            wait.until(ExpectedConditions.elementToBeClickable(loginButton)).click();
            Baseclass.extentTest.get().log(Status.INFO, "Clicked login button");

            wait.until(ExpectedConditions.invisibilityOf(loginButton));
            logger.info("Login successful for username: {}", username);
            Baseclass.extentTest.get().log(Status.PASS, "Login successful");

        } catch (Exception e) {
            logger.error("Login failed: {}", e.getMessage());
            Baseclass.extentTest.get().log(Status.FAIL, "Login failed: " + e.getMessage());
            Baseclass.extentTest.get().fail("Screenshot: " + Baseclass.extentTest.get().addScreenCaptureFromPath(Baseclass.captureScreenshot("login_failure")));
            throw e;
        }
    }
}