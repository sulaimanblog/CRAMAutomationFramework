package Pages;

import Base.Baseclass;
import Utitlities.Waitutilities;
import com.aventstack.extentreports.Status;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.support.ui.ExpectedCondition;
import org.openqa.selenium.support.ui.ExpectedConditions;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.time.Duration;
import java.util.Collections;

public class DashboardPage
{
    WebDriver driver;
    WebDriverWait wait;
    public static final Logger logger = LoggerFactory.getLogger(DashboardPage.class);

    @FindBy(xpath = "//div[@class='profile']")
    WebElement profileIcon;

    @FindBy(xpath = "//li[@role='presentation']")
    WebElement logoutLink;

    @FindBy(xpath = "//h1[contains(text(),'Dashboard')]")
    WebElement dashboardHeader;

    @FindBy(xpath = "//li[contains(@class,'nav-item')]/preceding::span[text()='Compliance Risk Register']")
    WebElement complianceRiskRegister;

    @FindBy(xpath = "//button[contains(text(),' Import File ')]")

    WebElement risk_Importbutton;

    @FindBy(xpath = "//span[contains(text(),'Select File ')]")
    WebElement risk_selectFileButton;

    @FindBy(xpath = "//input[@type='file']")
    WebElement fileInput;


    public DashboardPage(WebDriver driver) {
        this.driver = driver;
        this.wait = new WebDriverWait(driver, Duration.ofSeconds(15));
        PageFactory.initElements(driver, this);
    }

    public void logout() throws InterruptedException {
        try {
            logger.info("Attempting to logout");
            Baseclass.extentTest.get().log(Status.INFO, "Starting logout process");
           // Waitutilities.waitForElementsToBeVisible(Collections.singletonList(profileIcon));
            wait.until(ExpectedConditions.visibilityOfAllElements(profileIcon));
            profileIcon.click();
            Baseclass.extentTest.get().log(Status.INFO, "Clicked profile icon");
            // Waitutilities.waitForElementsToBeVisible(Collections.singletonList(logoutLink));
            wait.until(ExpectedConditions.visibilityOfAllElements(logoutLink));
            logoutLink.click();
            Baseclass.extentTest.get().log(Status.INFO, "Clicked logout link");

            wait.until(ExpectedConditions.invisibilityOf(profileIcon));
            logger.info("Logout successful");
            Baseclass.extentTest.get().log(Status.PASS, "Logout successful");

        } catch (Exception e) {
            logger.error("Logout failed: {}", e.getMessage());
            Baseclass.extentTest.get().log(Status.FAIL, "Logout failed: " + e.getMessage());
            Baseclass.extentTest.get().fail("Screenshot: " + Baseclass.extentTest.get().addScreenCaptureFromPath(Baseclass.captureScreenshot("logout_failure")));
            throw e;
        }
    }

    public  void risk_Compliance_Register() throws InterruptedException {
        try
        {
            logger.info("Attempting to Click the Risk Dashboard Page");
            Baseclass.extentTest.get().log(Status.INFO, "Starting Risk Dashbooard process");
            wait.until(ExpectedConditions.visibilityOfAllElements(complianceRiskRegister));
            complianceRiskRegister.click();

            /*//Below Import file Code
            wait.until(ExpectedConditions.elementToBeClickable(risk_Importbutton)).click();
            wait.until(ExpectedConditions.elementToBeClickable(risk_selectFileButton)).click();

            String filePath = System.getProperty("user.dir") + "/test-output/RiskRegisterFile/Risk_Register_File.xlsx";

            // Make the file input element visible if it's hidden
            ((JavascriptExecutor) driver).executeScript("arguments[0].style.display='block';", fileInput);

            // Send the file path to the input element
            fileInput.sendKeys(filePath);
            Baseclass.extentTest.get().log(Status.INFO, "File selected for import: " + filePath);*/



            Baseclass.extentTest.get().log(Status.INFO, "Clicked Risk Dashboard Page link");
            logger.info("Comliance successful clicked");
            Baseclass.extentTest.get().log(Status.PASS, " Successful Landed Complaince Risk Register Page");

        }
        catch (Exception e) {
            logger.error("Risk Compliance Register failed to click: {}", e.getMessage());
            Baseclass.extentTest.get().log(Status.FAIL, "Risk Compliance Register failed: " + e.getMessage());
            Baseclass.extentTest.get().fail("Screenshot: " + Baseclass.extentTest.get().addScreenCaptureFromPath(Baseclass.captureScreenshot("Risk_Compliance_Register_Failure")));
            throw e;
        }
    }


}