package Base;

import ConfigReader.ConfigReader;
import com.aventstack.extentreports.ExtentReports;
import com.aventstack.extentreports.ExtentTest;
import com.aventstack.extentreports.Status;
import com.aventstack.extentreports.markuputils.ExtentColor;
import com.aventstack.extentreports.markuputils.MarkupHelper;
import com.aventstack.extentreports.reporter.ExtentSparkReporter;
import com.aventstack.extentreports.reporter.configuration.Theme;
import io.github.bonigarcia.wdm.WebDriverManager;
import org.apache.commons.io.FileUtils;
import org.openqa.selenium.JavascriptExecutor;
import org.openqa.selenium.OutputType;
import org.openqa.selenium.TakesScreenshot;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.WebDriverWait;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.testng.ITestResult;
import org.testng.annotations.*;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.Method;
import java.time.Duration;


public class Baseclass
{
    public static WebDriver driver;
    WebDriverWait wait;
    final String BASE_URL = ConfigReader.getProperty("base.url");

    // Extent Report variables
    public static ExtentReports extent;
    public static ExtentTest test;
    public static ThreadLocal<ExtentTest> extentTest = new ThreadLocal<>();

    // Logger
    public static Logger logger = LoggerFactory.getLogger(Baseclass.class);

    @BeforeSuite
    public void initExtentReport() {
        String reportPath = System.getProperty("user.dir") + "/test-output/ExtentReport.html";
        ExtentSparkReporter sparkReporter = new ExtentSparkReporter(reportPath);

        // Configure to use relative paths for screenshots
        sparkReporter.config().setDocumentTitle("Automation Report");
        sparkReporter.config().setReportName("CRA Application Test Report");
        sparkReporter.config().setTheme(Theme.STANDARD);
        sparkReporter.config().setCss(".r-img { width: 50%; }");

        extent = new ExtentReports();
        extent.attachReporter(sparkReporter);

        extent.setSystemInfo("Application", "CRA Application");
        extent.setSystemInfo("Environment", "QA");
        extent.setSystemInfo("User", "Mohd Sulaiman");
    }

    @BeforeClass
    public void setup() {
        try {
            logger.info("Setting up WebDriver and initializing browser");
            WebDriverManager.chromedriver().setup();
            driver = new ChromeDriver();
            driver.manage().window().maximize();
            driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(5));
            wait = new WebDriverWait(driver, Duration.ofSeconds(15));
            driver.get(BASE_URL);
            wait.until(d -> ((JavascriptExecutor) d).executeScript("return document.readyState").equals("complete"));
            logger.info("Browser initialized and navigated to base URL: {}", BASE_URL);
        } catch (Exception e) {
            logger.error("Setup failed: {}", e.getMessage());
            throw new RuntimeException("Failed to initialize WebDriver", e);
        }
    }

    @BeforeMethod
    public void beforeMethod(Method method) {
        String testName = method.getName();
        test = extent.createTest(testName);
        extentTest.set(test);
        logger.info("Starting test: {}", testName);
    }

    @AfterMethod
    public void afterMethod(ITestResult result) {
        if (result.getStatus() == ITestResult.FAILURE) {
            extentTest.get().log(Status.FAIL, MarkupHelper.createLabel(result.getName() + " - Test Case Failed", ExtentColor.RED));
            extentTest.get().log(Status.FAIL, MarkupHelper.createLabel("Failure Reason: " + result.getThrowable(), ExtentColor.RED));

            // Capture screenshot on failure
            String screenshotPath = captureScreenshot(result.getName());
            if (screenshotPath != null) {
                try {
                    // Use relative path for the report
                    String relativePath = "./screenshots/" + new File(screenshotPath).getName();
                    extentTest.get().fail("Test Failed - Screenshot: " +
                            extentTest.get().addScreenCaptureFromPath(relativePath));
                } catch (Exception e) {
                    logger.error("Failed to attach screenshot to report: {}", e.getMessage());
                }
            }
            logger.error("Test {} failed: {}", result.getName(), result.getThrowable().getMessage());
        }
        // ... [rest of your existing afterMethod code] ...
    }

    @AfterClass
    public void tearDown() {
        if (driver != null) {
            driver.quit();
            logger.info("Browser closed");
        }
    }

    @AfterSuite
    public void flushExtentReport() {
        extent.flush();
        logger.info("Extent report generated");
    }

    public static String captureScreenshot(String screenshotName) {
        try {
            // Create screenshots directory if it doesn't exist
            File directory = new File("test-output/screenshots/");
            if (!directory.exists()) {
                directory.mkdirs();
            }

            TakesScreenshot ts = (TakesScreenshot) driver;
            File source = ts.getScreenshotAs(OutputType.FILE);

            // Simplify the filename and ensure it's a PNG
            String fileName = screenshotName.replaceAll("[^a-zA-Z0-9]", "_") + "_" +
                    System.currentTimeMillis() + ".png";

            String destination = directory.getAbsolutePath() + "/" + fileName;
            File finalDestination = new File(destination);
            FileUtils.copyFile(source, finalDestination);

            // Return the full path for reference
            return finalDestination.getAbsolutePath();
        } catch (Exception e) {
            logger.error("Failed to capture screenshot: {}", e.getMessage());
            return null;
        }
    }

    // ... [rest of your existing methods] ...
}


